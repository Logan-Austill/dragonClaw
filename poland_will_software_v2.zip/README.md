Execute with python3 main.py

Board dimensions must be altered within board_generatory.py -> generate_solved_board AND generate_puzzle
  Note: these values are squared to build board dimension ex: 3 = 9, 4 = 16 etc.
Empty cell ratio can also be altered via generate_puzzle

My portion was backtracking.py. I worked with Logan and Lexer on board.py, and main.py