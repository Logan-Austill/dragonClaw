Create a virtual environment
Make sure pulp 3.3.0 is installed. NOT latest version
Execute with python3 main.py

Board dimensions must be altered within board_generatory.py -> generate_solved_board AND generate_puzzle
  Note: these values are squared to build board dimension ex: 3 = 9, 4 = 16 etc.
Empty cell ratio can also be altered via generate_puzzle

My portion was lp_relaxation and board_generator. I worked with Will and Lexer on backtracking.py, board.py, and main.py